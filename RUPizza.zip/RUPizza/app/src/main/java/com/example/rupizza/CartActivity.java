package com.example.rupizza;
/**
 * This class handles the orders cart
 * you are allowed to clear the pizzas in the orders, or place the order.
 * @author Abhijeet Singh, Khizar Saud
 */
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.app.AlertDialog.Builder;

import android.os.Bundle;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import com.example.rupizza.Pizza;
import com.example.rupizza.StoreOrder;

import java.text.DecimalFormat;
import java.util.ArrayList;
public class CartActivity extends AppCompatActivity {
    private static final DecimalFormat df = new DecimalFormat("0.00");
    ArrayList<Pizza> listOfPizzas;



    RecyclerView cartofPizzas;
    Button clearCartButton, placeOrderButton;
    TextView orderNumber;
    static TextView subtotalP;
    static TextView salesxTax;
    static TextView cartTotalPrice;

    /**
     * This method initalizes the cart and sets the cart to its default state
     *
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.orderviewact);

        subtotalP = findViewById(R.id.subtotalP);
        salesxTax = findViewById(R.id.salesxTax);
        cartTotalPrice = findViewById(R.id.cartTotalPrice);
        orderNumber = findViewById(R.id.tvOrderNum);
        cartofPizzas = findViewById(R.id.pizzarecyle);
        clearCartButton = findViewById(R.id.btnClearCart);
        placeOrderButton = findViewById(R.id.btnPlaceOrder);

        listOfPizzas = new ArrayList<>();
        initalizeView();
        PizzaItemAdapter adapter = new PizzaItemAdapter(this, listOfPizzas); //create the adapter
        cartofPizzas.setAdapter(adapter); //bind the list of items to the RecyclerView
        cartofPizzas.setLayoutManager(new LinearLayoutManager(this));

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);


        clearCartButton.setOnClickListener(new View.OnClickListener() {
            AlertDialog.Builder alertDialog = new AlertDialog.Builder(CartActivity.this);

            @Override
            public void onClick(View v) {
                if (StoreOrder.getCurOrder().getPizzas().size() > 0) {
                    for (int i = 0; i <= StoreOrder.getCurOrder().getPizzas().size(); i++) {
                        StoreOrder.getCurOrder().getPizzas().remove(i);
                        adapter.notifyDataSetChanged();

                    }
                    listOfPizzas.clear();
                    adapter.notifyDataSetChanged();
                    update();
                }else{
                    alertDialog.setTitle("Cannot clear when no are in the pizza list!");
                    alertDialog.show();

                }
            }
        });

        placeOrderButton.setOnClickListener(new View.OnClickListener() {
            AlertDialog.Builder alertDialog = new AlertDialog.Builder(CartActivity.this);

            @Override
            public void onClick(View v) {
                if(StoreOrder.getCurOrder().getPizzas().size() < 1){

                    alertDialog.setTitle("No pizzas added to order");
                    alertDialog.setMessage("None");
                    alertDialog.setPositiveButton("OK",null);
                    alertDialog.show();

                    return;
                }
                StoreOrder.finish();
                alertDialog.setTitle("Success");
                alertDialog.setMessage("Order created");
                alertDialog.setPositiveButton("OK",null);

                alertDialog.show();

                Toast.makeText(CartActivity.this, "Order Placed", Toast.LENGTH_SHORT).show();
                adapter.notifyDataSetChanged();
                initalizeView();
            }
        });

        update();
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }


    private void initalizeView(){
        StoreOrder.getCurOrder().getOrderID();
        orderNumber.setText("Order Number: " +         StoreOrder.getCurOrder().getOrderID());

        listOfPizzas.clear();
        listOfPizzas.addAll(StoreOrder.getCurOrder().getPizzas());
        update();
    }


    public static void update(){
        subtotalP.setText(df.format(StoreOrder.getCurOrder().getSubTotal()));
        salesxTax.setText(df.format(StoreOrder.getCurOrder().getTax()));
        cartTotalPrice.setText(df.format(StoreOrder.getCurOrder().getTotal()));
    }
}