package com.example.rupizza;

public interface ToppingsRecyclerInterfaceNY {
    void onItemCLick(int Position);
}
