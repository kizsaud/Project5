package com.example.rupizza;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;

import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.util.ArrayList;
public class StoreOrderActivity extends AppCompatActivity {
    private TextView textView5;
    private Spinner spOrderNum;
    private TextView tvOrderTotal;
    private ListView lvOrder;
    private Order order;
    private static final DecimalFormat df = new DecimalFormat("0.00");

    /**
     * Create a StoreOrdersActivity activity, and load a past saved state
     * of the activity if the activity is being reloaded. Bind listeners for
     * all UI components.
     * @param savedInstanceState  past saved state of activity.
     */
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store_order);
        ActionBar actionBar = getSupportActionBar();

        // showing the back button in action bar
        textView5=findViewById(R.id.textView5);
        actionBar.setDisplayHomeAsUpEnabled(true);
        textView5.setText("Order Number:");



        spOrderNum = findViewById(R.id.spOrderNum);
        ImageView btnCancelOrder = findViewById(R.id.btnCancelOrder);
        tvOrderTotal = findViewById(R.id.tvOrderTotal);
        lvOrder = findViewById(R.id.lvOrder);

        spOrderNum.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                order = StoreOrder.getOrder(Integer.parseInt(spOrderNum.getSelectedItem().toString()));
                tvOrderTotal.setText(df.format(order.getTotal()));
                updateList();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                ArrayList<Integer> orderNums = StoreOrder.getOrderIDs();
                if(orderNums.size() > 0){
                    spOrderNum.setSelection(0);
                    order = StoreOrder.getOrder(Integer.parseInt(spOrderNum.getSelectedItem().toString()));
                }
            }
        });

        btnCancelOrder.setOnClickListener(v -> {
            if(spOrderNum.getSelectedItem() == null){
                Toast.makeText(StoreOrderActivity.this,
                        "No Order Selected", Toast.LENGTH_SHORT).show();
                return;
            }
            int orderNum = Integer.parseInt(spOrderNum.getSelectedItem().toString());
            StoreOrder.cancel(orderNum);
            Toast.makeText(StoreOrderActivity.this,
                    "Order " + orderNum + " cancelled", Toast.LENGTH_SHORT).show();
            init();
        });

        init();
    }

    /**
     * Populate UI components of the page upon creation of the activity
     * or deletion of an order.
     */
    private void init(){
        ArrayAdapter<Integer> orderNumAdapter = new ArrayAdapter<>(StoreOrderActivity.this,
                android.R.layout.simple_spinner_dropdown_item,
                StoreOrder.getOrderIDs());
        orderNumAdapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item);
        spOrderNum.setAdapter(orderNumAdapter);

        if(StoreOrder.getOrderIDs().size() > 0){
            spOrderNum.setSelection(0);
            order = StoreOrder.getOrder(Integer.parseInt(spOrderNum.getSelectedItem().toString()));
            updateList();
        }
        else{
            clearList();
        }
    }

    /**
     * Populate the ListView of orders by setting its adapter
     */
    private void updateList(){
        ArrayAdapter<Pizza> arrayAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                order.getPizzas());
        lvOrder.setAdapter(arrayAdapter);
    }


    private void clearList(){
        order = null;
        ArrayAdapter<Pizza> arrayAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                new ArrayList<>());
        lvOrder.setAdapter(arrayAdapter);
        String no_cost = "0.00";
        tvOrderTotal.setText(no_cost);
    }
}